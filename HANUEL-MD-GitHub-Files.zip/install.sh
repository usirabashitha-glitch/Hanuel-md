#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install nodejs-lts -y
npm install
[ -f .env ] || cp .env.example .env
echo 'Hanuel-MD installed. Edit .env, then run: npm start'
