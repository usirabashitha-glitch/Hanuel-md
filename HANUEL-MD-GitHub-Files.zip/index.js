require('dotenv').config();
const fs = require('fs');
const path = require('path');
const pino = require('pino');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const QRCode = require('qrcode');
const qrcodeTerminal = require('qrcode-terminal');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, jidNormalizedUser, getContentType } = require('@whiskeysockets/baileys');

const ROOT = __dirname;
const AUTH_DIR = path.join(ROOT, 'auth_info');
const CONFIG_FILE = path.join(ROOT, 'config.json');
const LOG_FILE = path.join(ROOT, 'bot.log');
const PORT = Number(process.env.PORT || 3000);
const OWNER = String(process.env.OWNER_NUMBER || '').replace(/\D/g, '');
let config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
let sock = null, qrData = '', connected = false, startedAt = Date.now(), reconnecting = false;
const stats = { messages: 0, commands: 0, groups: 0, lastEvent: 'Starting' };
const recentLogs = [];

function saveConfig() { fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2)); }
function log(message) {
  const line = `[${new Date().toISOString()}] ${message}`;
  console.log(line); recentLogs.unshift(line); if (recentLogs.length > 150) recentLogs.pop();
  fs.appendFileSync(LOG_FILE, line + '\n'); io.emit('log', line);
}
function isOwner(jid) { return !!OWNER && jidNormalizedUser(jid).split('@')[0] === OWNER; }
function unwrap(m) { let x = m; while (x?.ephemeralMessage || x?.viewOnceMessage || x?.viewOnceMessageV2) x = x.ephemeralMessage?.message || x.viewOnceMessage?.message || x.viewOnceMessageV2?.message; return x || {}; }
function getText(m) {
  const msg = unwrap(m.message); const type = getContentType(msg);
  if (!type) return '';
  const v = msg[type];
  return (type === 'conversation' ? v : v?.text || v?.caption || v?.contentText || '');
}
function duration() { const s = Math.floor((Date.now() - startedAt) / 1000); return `${Math.floor(s/3600)}h ${Math.floor(s%3600/60)}m ${s%60}s`; }
function reply(jid, text, quoted) { return sock.sendMessage(jid, { text }, quoted ? { quoted } : {}); }
function menu() {
 return `╭━━〔 *${config.botName}* 〕━━╮\n│ Prefix: ${config.prefix}\n│ Runtime: ${duration()}\n╰━━━━━━━━━━━━━━╯\n\n*GENERAL*\n${config.prefix}menu • ${config.prefix}ping\n${config.prefix}info • ${config.prefix}owner\n${config.prefix}sticker (reply to image/video)\n${config.prefix}toimg (reply to sticker)\n${config.prefix}say <text> • ${config.prefix}calc <math>\n\n*GROUP ADMIN*\n${config.prefix}tagall [text] • ${config.prefix}admins\n${config.prefix}groupinfo • ${config.prefix}link\n${config.prefix}promote @user • ${config.prefix}demote @user\n${config.prefix}kick @user • ${config.prefix}open • ${config.prefix}close\n${config.prefix}welcome on/off • ${config.prefix}antilink on/off\n\n*OWNER*\n${config.prefix}broadcast <text> • ${config.prefix}setprefix <symbol>\n${config.prefix}mode public/self • ${config.prefix}restart\n\nAdmin panel: http://localhost:${PORT}`;
}
async function handleCommand(m) {
 const jid = m.key.remoteJid, sender = m.key.participant || m.key.remoteJid;
 const text = getText(m).trim(); if (!text.startsWith(config.prefix)) return;
 const [raw, ...args] = text.slice(config.prefix.length).trim().split(/\s+/); const cmd = (raw || '').toLowerCase();
 if (!cmd || config.disabledCommands.includes(cmd)) return;
 const group = jid.endsWith('@g.us'); const owner = isOwner(sender); const metadata = group ? await sock.groupMetadata(jid).catch(() => null) : null;
 const participants = metadata?.participants || []; const adminList = participants.filter(p => p.admin).map(p => p.id);
 const isAdmin = adminList.includes(jidNormalizedUser(sender)); const botJid = jidNormalizedUser(sock.user.id); const botAdmin = adminList.includes(botJid);
 const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
 const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
 const target = mentioned[0] || (args[0]?.replace(/\D/g, '') ? `${args[0].replace(/\D/g, '')}@s.whatsapp.net` : null);
 const needGroup = () => { if (!group) { reply(jid, 'මෙම command එක group එකක භාවිතා කරන්න.', m); return false; } return true; };
 const needAdmin = () => { if (!needGroup()) return false; if (!isAdmin && !owner) { reply(jid, 'Group admin කෙනෙකුට පමණයි.', m); return false; } if (!botAdmin) { reply(jid, 'Bot එකට group admin බලය ලබා දෙන්න.', m); return false; } return true; };
 const needOwner = () => { if (!owner) { reply(jid, 'Owner පමණයි.', m); return false; } return true; };
 stats.commands++; stats.lastEvent = `${cmd} by ${sender.split('@')[0]}`;
 try {
 switch (cmd) {
 case 'menu': case 'help': return reply(jid, menu(), m);
 case 'ping': return reply(jid, `Pong! ${Date.now() - (m.messageTimestamp * 1000 || Date.now())}ms\nUptime: ${duration()}`, m);
 case 'info': return reply(jid, `*${config.botName}*\nBaileys multi-device bot\nNode: ${process.version}\nUptime: ${duration()}\nMode: ${config.publicMode ? 'Public' : 'Self'}`, m);
 case 'owner': return reply(jid, OWNER ? `Owner: +${OWNER}` : 'Set OWNER_NUMBER in .env first.', m);
 case 'say': return reply(jid, args.join(' ') || 'Usage: say <text>', m);
 case 'calc': { const exp = args.join(' '); if (!/^[0-9+*/().%\s-]+$/.test(exp) || !exp) return reply(jid, 'භාවිතය: calc 10+5*2', m); const result = Function(`"use strict";return (${exp})`)(); return reply(jid, `Result: ${result}`, m); }
 case 'setprefix': if (!needOwner()) return; if (!args[0] || args[0].length > 2) return reply(jid, 'Usage: setprefix <symbol>', m); config.prefix = args[0]; saveConfig(); return reply(jid, `Prefix updated: ${config.prefix}`, m);
 case 'mode': if (!needOwner()) return; config.publicMode = args[0] !== 'self'; saveConfig(); return reply(jid, `Mode: ${config.publicMode ? 'public' : 'self'}`, m);
 case 'restart': if (!needOwner()) return; await reply(jid, 'Restarting process...', m); setTimeout(() => process.exit(0), 700); return;
 case 'tagall': { if (!needAdmin()) return; const mentions = participants.map(p => p.id); const body = args.join(' ') || 'Attention everyone!'; return sock.sendMessage(jid, { text: `*${body}*\n\n` + mentions.map(x => `@${x.split('@')[0]}`).join(' '), mentions }); }
 case 'admins': if (!needGroup()) return; return sock.sendMessage(jid, { text: `*Group admins*\n${adminList.map(x => `• @${x.split('@')[0]}`).join('\n')}`, mentions: adminList });
 case 'groupinfo': if (!needGroup()) return; return reply(jid, `*${metadata.subject}*\nMembers: ${participants.length}\nAdmins: ${adminList.length}\nID: ${jid}`, m);
 case 'link': if (!needAdmin()) return; { const code = await sock.groupInviteCode(jid); return reply(jid, `https://chat.whatsapp.com/${code}`, m); }
 case 'promote': if (!needAdmin()) return; if (!target) return reply(jid, 'User කෙනෙකු mention කරන්න.', m); await sock.groupParticipantsUpdate(jid, [target], 'promote'); return reply(jid, 'Promoted.', m);
 case 'demote': if (!needAdmin()) return; if (!target) return reply(jid, 'User කෙනෙකු mention කරන්න.', m); await sock.groupParticipantsUpdate(jid, [target], 'demote'); return reply(jid, 'Demoted.', m);
 case 'kick': if (!needAdmin()) return; if (!target) return reply(jid, 'User කෙනෙකු mention කරන්න.', m); await sock.groupParticipantsUpdate(jid, [target], 'remove'); return reply(jid, 'Member removed.', m);
 case 'open': if (!needAdmin()) return; await sock.groupSettingUpdate(jid, 'not_announcement'); return reply(jid, 'Group opened.', m);
 case 'close': if (!needAdmin()) return; await sock.groupSettingUpdate(jid, 'announcement'); return reply(jid, 'Group closed.', m);
 case 'welcome': if (!needAdmin()) return; config.welcomeGroups = config.welcomeGroups.filter(x => x !== jid); if (args[0] === 'on') config.welcomeGroups.push(jid); config.welcome = args[0] === 'on'; saveConfig(); return reply(jid, `Welcome ${args[0] === 'on' ? 'enabled' : 'disabled'} for this group.`, m);
 case 'antilink': if (!needAdmin()) return; config.antiLinkGroups = config.antiLinkGroups.filter(x => x !== jid); if (args[0] === 'on') config.antiLinkGroups.push(jid); saveConfig(); return reply(jid, `Anti-link ${args[0] === 'on' ? 'enabled' : 'disabled'}.`, m);
 case 'broadcast': if (!needOwner()) return; { const msg = args.join(' '); if (!msg) return reply(jid, 'Usage: broadcast <message>', m); const groups = await sock.groupFetchAllParticipating(); let sent = 0; for (const id of Object.keys(groups)) { await sock.sendMessage(id, { text: `*${config.botName} Broadcast*\n\n${msg}` }).catch(() => {}); sent++; } return reply(jid, `Broadcast sent to ${sent} groups.`, m); }
 case 'sticker': case 's': { const msg = quoted ? { ...m, message: quoted } : m; const imageMsg = msg.message?.imageMessage; const videoMsg = msg.message?.videoMessage; if (!imageMsg && !videoMsg) return reply(jid, 'Image/video එකකට reply කරලා .sticker යවන්න. (Sticker conversion සඳහා ffmpeg අවශ්‍යයි.)', m); const { downloadContentFromMessage } = require('@whiskeysockets/baileys'); const stream = await downloadContentFromMessage(imageMsg || videoMsg, imageMsg ? 'image' : 'video'); const chunks = []; for await (const c of stream) chunks.push(c); const buf = Buffer.concat(chunks); const sharp = require('sharp'); const webp = await sharp(buf).resize(512, 512, { fit: 'inside' }).webp().toBuffer(); return sock.sendMessage(jid, { sticker: webp }, { quoted: m }); }
 default: return;
 }
 } catch (e) { log(`Command ${cmd} failed: ${e.message}`); return reply(jid, `Command error: ${e.message}`, m).catch(() => {}); }
}

async function startBot() {
 if (reconnecting) return; reconnecting = true;
 const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
 let version; try { ({ version } = await fetchLatestBaileysVersion()); } catch { version = undefined; }
 sock = makeWASocket({ version, auth: state, logger: pino({ level: 'silent' }), printQRInTerminal: false, browser: ['Hanuel-MD', 'Chrome', '1.0.0'], markOnlineOnConnect: false, syncFullHistory: false });
 sock.ev.on('creds.update', saveCreds);
 sock.ev.on('connection.update', async update => {
  const { connection, lastDisconnect, qr } = update;
  if (qr) { qrData = await QRCode.toDataURL(qr); qrcodeTerminal.generate(qr, { small: true }); log('Scan QR from the admin panel to connect WhatsApp.'); io.emit('status', status()); }
  if (connection === 'open') { connected = true; qrData = ''; reconnecting = false; log(`Connected as ${sock.user?.id || 'WhatsApp account'}`); io.emit('status', status()); }
  if (connection === 'close') { connected = false; qrData = ''; reconnecting = false; const code = lastDisconnect?.error?.output?.statusCode; log(`Connection closed (${code || 'unknown'}).`); io.emit('status', status()); if (code !== DisconnectReason.loggedOut) setTimeout(startBot, 2500); else log('Logged out. Remove auth_info folder and scan a new QR.'); }
 });
 sock.ev.on('messages.upsert', async ({ messages, type }) => {
  if (type !== 'notify') return;
  for (const m of messages) {
   if (!m.message || m.key.fromMe || m.key.remoteJid === 'status@broadcast') continue;
   stats.messages++; stats.lastEvent = `Message from ${m.key.remoteJid}`;
   if (config.autoRead) await sock.readMessages([m.key]).catch(() => {});
   const sender = m.key.participant || m.key.remoteJid;
   if (!config.publicMode && !isOwner(sender)) continue;
   const body = getText(m);
   if (m.key.remoteJid.endsWith('@g.us') && config.antiLinkGroups.includes(m.key.remoteJid) && /chat\.whatsapp\.com\//i.test(body) && !isOwner(sender)) {
    const meta = await sock.groupMetadata(m.key.remoteJid).catch(() => null); const admin = meta?.participants?.some(p => p.id === sender && p.admin);
    if (!admin) { await sock.sendMessage(m.key.remoteJid, { text: 'WhatsApp group links are not allowed here.' }, { quoted: m }); continue; }
   }
   await handleCommand(m);
  }
 });
 sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
  if (!config.welcomeGroups.includes(id) || !config.welcome || action !== 'add') return;
  for (const user of participants) await sock.sendMessage(id, { text: `Welcome @${user.split('@')[0]} to the group!`, mentions: [user] }).catch(() => {});
 });
}

const app = express(); const server = http.createServer(app); const io = new Server(server);
app.use(express.urlencoded({ extended: false })); app.use(express.json()); app.use(express.static(path.join(ROOT, 'public')));
function auth(req, res, next) {
 const h = req.headers.authorization || ''; const token = h.startsWith('Basic ') ? Buffer.from(h.slice(6), 'base64').toString() : '';
 const [u, ...p] = token.split(':'); const pass = p.join(':');
 if (u === (process.env.PANEL_USERNAME || 'admin') && pass === (process.env.PANEL_PASSWORD || 'change-this-password') && pass !== 'change-this-password') return next();
 res.set('WWW-Authenticate', 'Basic realm="Hanuel-MD Admin"'); return res.status(401).send('Authentication required. Set PANEL_USERNAME and PANEL_PASSWORD in .env');
}
function status() { return { connected, qr: qrData, botName: config.botName, prefix: config.prefix, uptime: duration(), stats, config: { welcome: config.welcome, antiLinkGroups: config.antiLinkGroups.length, publicMode: config.publicMode, autoRead: config.autoRead } }; }
app.get('/api/status', auth, (req, res) => res.json(status()));
app.get('/api/logs', auth, (req, res) => res.json(recentLogs));
app.get('/api/config', auth, (req, res) => res.json(config));
app.post('/api/config', auth, (req, res) => { const allowed = ['botName','prefix','welcome','antiLink','autoRead','publicMode']; for (const k of allowed) if (req.body[k] !== undefined) config[k] = req.body[k]; saveConfig(); log('Configuration updated from admin panel.'); res.json({ ok: true, config }); });
app.post('/api/logout', auth, async (req, res) => { try { await sock?.logout(); res.json({ ok: true }); } catch(e) { res.status(500).json({ error: e.message }); } });
io.on('connection', socket => socket.emit('status', status()));
server.listen(PORT, '0.0.0.0', () => log(`Admin panel listening on port ${PORT}`));
startBot().catch(e => { reconnecting = false; log(`Startup error: ${e.stack || e}`); });
