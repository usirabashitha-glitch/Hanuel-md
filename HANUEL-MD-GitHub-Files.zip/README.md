# Hanuel-MD v2.0

A mobile-friendly WhatsApp multi-device bot starter with a protected web admin panel. Built with the maintained `@whiskeysockets/baileys` package.

## Features
- QR-based WhatsApp multi-device login and saved session
- Responsive admin dashboard: connection status, QR, runtime, message/command counts, live logs
- Admin settings: bot name, prefix, welcome toggle, auto-read and public/self mode
- Commands: menu, ping, info, owner, say, calc, sticker (image), setprefix, mode, restart, broadcast
- Group tools: tagall, admins, groupinfo, invite link, promote, demote, kick, open/close, welcome, anti-link
- Config and session stored locally

## Install on Termux
1. Install Termux from a trusted source and run:
   ```sh
   pkg update && pkg upgrade -y
   pkg install nodejs-lts git -y
   ```
2. Extract this ZIP, enter the project folder, then:
   ```sh
   cp .env.example .env
   nano .env
   ```
3. Set `OWNER_NUMBER` to your WhatsApp number with country code and no `+` sign. Change `PANEL_USERNAME` and `PANEL_PASSWORD` to private values.
4. Install and run:
   ```sh
   npm install
   npm start
   ```
5. Open `http://127.0.0.1:3000` in your phone browser. Sign in using the panel username/password from `.env`, then scan the QR using WhatsApp → Linked devices.

## Commands
Default prefix is `.`. Send `.menu` in WhatsApp for the command list. Group-management commands require the sender to be a group admin and the bot to be a group admin. Owner commands require `OWNER_NUMBER` to be configured.

## Admin panel security
- Never share the panel URL, credentials, QR code, or `auth_info` folder.
- Use a strong unique panel password. Do not expose port 3000 directly to the public internet; use a trusted HTTPS reverse proxy if remote access is required.
- Keep `.env`, `auth_info/`, and backups private. The panel uses HTTP Basic Authentication.

## Notes
- Requires Node.js 20 or newer.
- WhatsApp may change its protocol; Baileys is an unofficial library and is not affiliated with WhatsApp. Use responsibly and avoid bulk/spam messaging.
- Sticker conversion uses the optional `sharp` package. Install it with `npm install sharp` if you want `.sticker` image conversion on your platform.
